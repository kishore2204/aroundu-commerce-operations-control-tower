/* Port of core/models/support-ticket-categories.ts - the category/sub-category taxonomy per raiser role. */
(function () {
  const STAFF_CATEGORIES = {
    ZONE_OPERATIONS: ['STAFFING_SHORTAGE', 'COVERAGE_GAP', 'PARTNER_DISPUTE'],
    POLICY_CLARIFICATION: ['POLICY_QUERY', 'APPROVAL_REQUEST'],
    SYSTEM_TECHNICAL: ['PLATFORM_BUG', 'DATA_DISCREPANCY', 'ACCESS_PERMISSION_ISSUE'],
    OTHER: ['GENERAL_QUERY'],
  };
  const SUPPORT_TICKET_CATEGORIES = {
    CUSTOMER: {
      ORDER_ISSUE: ['ITEM_MISSING', 'WRONG_ITEM_DELIVERED', 'ITEM_DAMAGED', 'ORDER_NOT_DELIVERED', 'LATE_DELIVERY', 'ORDER_CANCELLED_BY_RETAILER'],
      PAYMENT_ISSUE: ['PAYMENT_FAILED_AMOUNT_DEBITED', 'REFUND_NOT_RECEIVED', 'DOUBLE_CHARGE', 'INVOICE_DISCREPANCY'],
      DELIVERY_ISSUE: ['DELIVERY_PARTNER_BEHAVIOR', 'WRONG_DELIVERY_ADDRESS', 'CONTACTLESS_DELIVERY_NOT_FOLLOWED'],
      RETURN_REFUND: ['RETURN_REQUEST', 'REFUND_STATUS_QUERY', 'REPLACEMENT_REQUEST'],
      ACCOUNT_ISSUE: ['LOGIN_ISSUE', 'OTP_NOT_RECEIVED', 'PROFILE_UPDATE_ISSUE'],
      APP_TECHNICAL: ['APP_CRASH_OR_ERROR', 'PAYMENT_GATEWAY_ERROR', 'BUG_REPORT'],
      OTHER: ['GENERAL_QUERY', 'FEEDBACK_SUGGESTION'],
    },
    RETAILER: {
      ORDER_MANAGEMENT: ['ORDER_NOT_VISIBLE', 'CANNOT_ACCEPT_REJECT_ORDER', 'CANCELLATION_DISPUTE'],
      PAYOUT_SETTLEMENT: ['SETTLEMENT_DELAYED', 'SETTLEMENT_AMOUNT_MISMATCH', 'BANK_ACCOUNT_UPDATE_REQUEST'],
      PRODUCT_LISTING: ['CANNOT_ADD_EDIT_PRODUCT', 'INVENTORY_SYNC_ISSUE', 'PRICING_ISSUE'],
      ACCOUNT_VERIFICATION: ['DOCUMENT_REJECTED', 'VERIFICATION_DELAYED', 'GST_REGISTRATION_UPDATE'],
      APP_TECHNICAL: ['APP_CRASH_OR_ERROR', 'LOGIN_ISSUE', 'BUG_REPORT'],
      OTHER: ['GENERAL_QUERY', 'FEEDBACK_SUGGESTION'],
    },
    FLEET_MANAGER: {
      VEHICLE_ISSUE: ['VEHICLE_BREAKDOWN', 'DOCUMENT_EXPIRY_RENEWAL', 'VERIFICATION_DELAYED'],
      DRIVER_ISSUE: ['DRIVER_UNAVAILABLE', 'LICENSE_EXPIRY', 'DRIVER_CONDUCT_CONCERN'],
      ASSIGNMENT_ISSUE: ['TRIP_NOT_ASSIGNED', 'INCORRECT_ASSIGNMENT', 'ASSIGNMENT_CONFLICT'],
      PAYMENT_EXPENSE: ['EXPENSE_NOT_APPROVED', 'SETTLEMENT_DELAYED', 'SALARY_PAYMENT_DELAY'],
      APP_TECHNICAL: ['APP_CRASH_OR_ERROR', 'LOGIN_ISSUE', 'BUG_REPORT'],
      OTHER: ['SAFETY_CONCERN', 'GENERAL_QUERY'],
    },
    DRIVER: {
      PAYOUT_ISSUE: ['SALARY_PAYMENT_DELAY', 'EXPENSE_NOT_REIMBURSED', 'PAYOUT_AMOUNT_MISMATCH'],
      TRIP_ISSUE: ['TRIP_NOT_ASSIGNED', 'INCORRECT_ROUTE_INFO', 'CUSTOMER_BEHAVIOR_CONCERN'],
      SAFETY_CONDUCT: ['HARASSMENT_COMPLAINT', 'UNSAFE_ROUTE_CONDITION', 'ACCIDENT_REPORT'],
      VEHICLE_ISSUE: ['VEHICLE_CONDITION_CONCERN', 'MAINTENANCE_REQUEST'],
      APP_TECHNICAL: ['APP_CRASH_OR_ERROR', 'LOGIN_ISSUE', 'BUG_REPORT'],
      OTHER: ['GENERAL_QUERY'],
    },
    LOCATION_MANAGER: STAFF_CATEGORIES,
    OPERATIONS_MANAGER: STAFF_CATEGORIES,
    SUPER_ADMIN: STAFF_CATEGORIES,
    SUPPORT_STAFF: STAFF_CATEGORIES,
  };
  const LABEL_OVERRIDES = { APP_CRASH_OR_ERROR: 'App crash or error', OTP_NOT_RECEIVED: 'OTP not received', GST_REGISTRATION_UPDATE: 'GST registration update' };
  window.SupportCategories = {
    SUPPORT_TICKET_CATEGORIES,
    categoryLabel(code) {
      if (LABEL_OVERRIDES[code]) return LABEL_OVERRIDES[code];
      return String(code).toLowerCase().split('_').map((w) => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    },
    categoriesForRole: (role) => SUPPORT_TICKET_CATEGORIES[role] || {},
  };
})();

/* Port of shared/support/support-sla.util.ts - SLA countdown badge of a ticket. */
(function () {
  /* support-sla.util.ts */
  const TERMINAL_STATUSES = new Set(['RESOLVED', 'CLOSED']);
  function slaState(ticket) {
    if (!ticket.dueBy || TERMINAL_STATUSES.has(ticket.ticketStatus)) return null;
    const remainingMs = new Date(ticket.dueBy).getTime() - Date.now();
    if (remainingMs <= 0) return 'breached';
    if (remainingMs < 4 * 60 * 60 * 1000) return 'at-risk';
    return 'ok';
  }
  function slaLabel(ticket) {
    if (!ticket.dueBy || TERMINAL_STATUSES.has(ticket.ticketStatus)) return null;
    const remainingMs = new Date(ticket.dueBy).getTime() - Date.now();
    const overdue = remainingMs <= 0;
    const totalHours = Math.ceil(Math.abs(remainingMs) / (60 * 60 * 1000));
    const magnitude = totalHours >= 24 ? `${Math.ceil(totalHours / 24)}d` : `${totalHours}h`;
    return overdue ? `Overdue by ${magnitude}` : `${magnitude} left`;
  }
  window.SupportSla = { slaState, slaLabel };
})();
